
The file "TAppEncoderStatic" is the executable file of the occupancy map guided fast Video-based Point Cloud Compression (OMG_VPCC) method.

To run this method，please download it and replace the same file in file fold "..tmc2\HM-16.18+SCM-8.7\bin".

The file“_exePC.sh”is a batch file for test the five typical point clouds, including queen, loot, longdress, redandblack, and soldier.

The detailed test conditions are provided in file "_exePC.sh".

If you have any questions, you can contact Jian Xiong via email: jxiong@njupt.edu.cn.